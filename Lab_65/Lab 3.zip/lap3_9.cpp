#include<stdio.h>

int main()
{
	int n=3;
	int num[n],i,j,tmp;
	
	for(i=0;i<n;i++)
	{
		scanf("%d",&num[i]);
	}
	for(j=0;j<n;j++)
	{
		for(i=0;i<n;i++)
		{
			if(num[i]>num[i+1] && i< n-1)
			{
				tmp=num[i+1];
				num[i+1]=num[i];
				num[i]=tmp;
			}
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",num[i]);
	}
	return 0;
}
