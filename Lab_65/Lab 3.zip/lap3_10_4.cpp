#include<stdio.h>

int main()
{
	int i=0,j,n;
	int b[100];
	
	printf("Decimal value:");
	scanf("%d",&n);
	do
	{
		b[i]=n%2;
		n/=2;
		i++;
	}while(n>0);
	
	printf("Binary value is ");
	for(j=i-1;j>=0;j--)
	{
		printf("%d",b[j]);
	}
	return 0;
}
