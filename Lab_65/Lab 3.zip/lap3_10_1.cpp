#include<stdio.h>
int main()
{
	int i,n=9;
	int b[8]={1};
	
	for(i=1;i<n;i++)
	{
		b[i]=b[i-1]+b[i-2];
		b[1]=0;
		b[3]=0;
	}
	for(i=1;i<n;i++)
	{
		printf("b[%d]=%d\n",i,b[i]);
	}
	return 0;
}
