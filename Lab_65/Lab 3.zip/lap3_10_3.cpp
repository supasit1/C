#include<stdio.h>

int main()
{
	int i,n=9,s;
	int b[8];
	
	for(i=1;i<n;i++)
	{
		b[i]=b[i-1]+b[i-2];
		b[2]=b[1];
		b[1]=b[1+1];
		b[1+1]=b[2];
	}
	for(i=1;i<n;i++)
	{
		printf("b[%d]=%d\n",i,b[i]);
	}
	return 0;
}
