#include<stdio.h>
#include<string.h>
int main()
{
	char s[99];
	int i,n,alp,di,sp;
	gets(s);
	while(s[i]!='\0')
	{
		if((s[i]>= 65 && s[i]<=90)||s[i]>=97 && s[i]<=122)
		{
			alp++;
		}
		else if(s[i]>='0'&&s[i]<='9')
		{
			di++;
		}
		else if (s[i]>=33 && s[i]<=47)
		{
			sp++;
		}
		i++;
	}
	printf("alp= %d\n",alp);
	printf("di= %d\n",di);
	printf("sp= %d\n",sp);
	return 0;
}
