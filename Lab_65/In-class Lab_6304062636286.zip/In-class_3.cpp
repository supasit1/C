#include<stdio.h>
#include<string.h>
int main()
{
	int i,n;
	char s[99];
	int f;
	scanf("%s",s);
	n=strlen(s);
	for(i=0;i<n;i++)
	{
		if(s[i]!=s[n-i-1])
		{
			f=1;
			break;
		}
	}
	if(f==0)
	{
		printf("%s is not Palindrome ",s);
	}
	else
	{
		printf("%s is Palindrome",s);
	}
	return 0;
}
