#include<stdio.h>

int main()
{
	int i,n[99],sum=0;
	
	for(i=0;i<5;i++)
	{
		scanf("%d",&n[i]);
		if(n[i]%2!=0)
		{
			sum=sum+n[i];
		}
	}
	printf("%d",sum);
}
