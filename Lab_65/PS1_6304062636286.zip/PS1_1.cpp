#include<stdio.h>
int main ()
{
	char name[20];
	int year,age;
	printf("First Name:",name);
	scanf("%s",name);
	printf("Year of Birth:");
	scanf("%d",&year);
	
	age=2022-year;
	printf("Hi,%s,you are %d years old.",name,age);
	if(age>=20)
	{
		printf("Welcome to Cheers bar.\n");
	}
	else
	{
		printf("You must be 20 to enter this bar,please comeback in %d years\n",20-age);
	}
	printf("Bye!");
	return 0;
}
