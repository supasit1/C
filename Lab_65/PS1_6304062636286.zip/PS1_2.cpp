#include<stdio.h>
#define pi 3.1416
int main()
{
	float r,h,v;
	
	printf("Enter radius and height of cylinder:");
	scanf("%f %f",&r,&h);
	v=pi*(r*r)*h;
	printf("Volume of Cylinder radius %.2f height %.2f is %.2f",r,h,v);
}
