#include<stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
	char c;
	int y,x,count=0;
	
	srand(time(NULL));
	x=rand()%100;
	
	do
	{
		printf("count up %d time\n",count+1);
		printf("Enter guess value:");
		scanf("%d",&y);
		count++;
		if(y==x)
		{
			printf("You win.");
			break;
		}
		else
	{
		 if(y<x)
		 	{
		 		printf("worng...too low.\n\n");
			}
		else
		{
			printf("Worng...too high\n\n");
		}
		}
		if(count==7)
		{
			printf("You lose.\n");
		}
	}while(count < 7);
	printf("\n");
	printf("Game is End");
	return 0;
}
