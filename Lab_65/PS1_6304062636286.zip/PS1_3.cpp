#include<stdio.h>

int main()
{
	char str[30] = "CS 2022"; 
	int a = 180; 
	double r = 13.14; 
	int b=-5; 
	int c=-12;
	double s=786.256;
	printf("**%s**\n",str);
	printf("**%10s**\n",str );
	printf("**%-10s**\n",str );
	printf("**%d**\n",a );
	printf("**%10d**\n",a );
	printf("**%-10d**\n",a );
	printf("**%lf**\n", r );
	printf("**%.2lf**\n", r );
	printf("**%12.2lf**\n", r );
	printf("**%e**\n", r );
	printf("**%.2e**\n", s );
	printf("**%.2lf**\n", s );
	printf("**%12.2lf**\n", s );
	printf("*+%dX+%d*\n", b, c );
	printf("*%+dX%+d*\n", b, c );
	printf("*%dX+%d*\n", b, c );
	printf("*%dX%+d*\n", b, a );
	printf("*%+dX%+d*\n", a, c );
}
