#include<stdio.h>

int main()
{
	int i,n,x[100];
	printf("Enter multiply number:");
	scanf("%d",&n);
	printf("Multiply table x %d\n",n);
	
	for(i=0;i<=12;i++)
	{
		x[i]=i*n;
	}
	printf("+----------+----------+\n");
	printf("|multiply  |  result  |\n");
	printf("|----------|----------|\n");
	for(i=1;i<=12;i++)
	{
		printf("|%3d x %2d  | %7d  |\n",n,i,x[i]);
	}
	printf("+----------+----------+\n");
	return 0;
}

