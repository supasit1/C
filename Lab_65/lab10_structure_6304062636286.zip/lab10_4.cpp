#include<stdio.h>
int face_values(char c);
int suits(char c);

typedef struct
{
	char fv;
	char sut;
}card;

int main()
{
	int i,j,n,sum=0;
	char cfv,cs;
	scanf("%d",&n);
	getchar();
	card c[n];
	
	for(i=0;i<n;i++)
	{
		scanf("%c %c",&c[i].fv,&c[i].sut);
		getchar();
	}
	
	for(i=0;i<n;i++){
		for(j=i+1;j<n;j++){
			
			if(face_values(c[i].fv)>face_values(c[j].fv)){
				cfv = c[j].fv;
				c[j].fv = c[i].fv;
				c[i].fv = cfv;
				
				cs = c[j].sut;
				c[j].sut = c[i].sut;
				c[i].sut = cs;
			}
			
			else if(face_values(c[i].fv)==face_values(c[j].fv)){
				if (suits(c[i].sut)>suits(c[j].sut)){ 
					cs = c[j].sut;
					c[j].sut = c[i].sut;
					c[i].sut = cs;
				}
			}
		}
	}
	
	for(i=0;i<n;i++)
	{
		printf("%c-%c,",c[i].fv,c[i].sut);
		sum+=face_values(c[i].fv);
	}
	printf("\n%d\n",sum);
	
	return 0;
}

int face_values(char c)
{
	if(c-48>=2 && c-48<=9)
	{
		return c-48	;
	}
	else
	{
		switch(c)
		{
			case 'A': return 1; break;
			case 'J': return 10;break;
			case 'Q': return 11;break;
			case 'K': return 12;break;
		}
	}
}

int suits(char c)
{
	switch (c)
	{
		case 'C': return 1; break;
		case 'D': return 2; break;
		case 'H': return 3; break;
		case 'S': return 4; break;
	}
}
