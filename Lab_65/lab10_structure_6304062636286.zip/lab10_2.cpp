#include<stdio.h>
#include<math.h>
float FindLength(float x,float y,float z);
typedef struct
{
	float x;
	float y;
	float z;
}vector3D;

int main()
{
	int i,n;
	float re;
	vector3D v;
	
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		scanf("%f %f %f",&v.x,&v.y,&v.z);
	}
	
	re=FindLength(v.x,v.y,v.z);
	printf("%.2f\n",re);
	return 0;
}

float FindLength(float x,float y,float z)
{
	return sqrt((x*x)+(y*y)+(z*z));
}
