#include <stdio.h>
typedef struct
{
	int _1000,_500,_100,_50,_20,_10,_1;
}money;

money count(int m);

int main()
{
	int m;
	scanf("%d",&m);
	
	money th;
	
	th = count(m);
	printf("%d %d %d %d %d %d %d\n",th._1000,th._500,th._100,th._50,th._20,th._10,th._1);
}

money count(int m){
	money b;
	
	b._1000= m/1000;
	m = m%1000;
 	
    b._500= m/500;
	m = m%500;
	
	b._100= m/100;
	m = m%100;
	
	b._50= m/50;
	m = m%50;
	
	b._20= m/20;
	m = m%20;
	
	b._10= m/10;
	m = m%10;
	
	b._1= m/1;
	m = m%1;
	return b;
}
