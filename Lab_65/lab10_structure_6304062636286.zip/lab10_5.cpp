#include<stdio.h>
#include<ctype.h>
typedef struct 
{
	int num;
	
}stack;
int main()
{
	int i,n,count=0;
	char op;
	printf("How many data : ");
	scanf("%d",&n);
	stack st[n];
	stack *top=st;
	for(i=0;i<n;i++)
	{
		st[i].num=0;
	}
	
	printf("Operator :\nP : Push data.\nX : Pop data.\nE : Exit.\n");

	do
	{
		getchar();
		printf("Please select operation: ");
		scanf("%c",&op);
		if(toupper(op) =='P')
		{
			for(i=0;i<n;i++)
			{
				if(st[i].num != 0)
				{
					count++;	
				}
			}
			if(count==n)
			{
				printf("STACK IS FULL.\n");
			}
			else 
			{
				printf("Please input data:");
				if(top->num!=0)
					{
						top++;
					}
				scanf("%d",&top->num);
			}
		}
		else if (toupper(op) =='X')
		{
			for(i=0;i<n;i++)
			{
				if(st[i].num==0)
				{
					count++;
				}
			}
			if(count==n)
			{
				printf("STACK IS FULL.\n");
			}
			else
			{
				printf("Data is: %d\n",top->num);
				top->num=0;
				top--;	
			} 		
		}
		else if(toupper(op)=='E')
		{
			break;
		}
		printf("stack = ");
		for(i=0;i<n;i++)
		{
			printf("%d ",st[i].num);	
		}
		printf("\n");
	}while(toupper(op)!='E');
	
	return 0;
}
