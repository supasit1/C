#include<stdio.h>
#include<math.h>

void Quadrant(int x,int y);
typedef struct
	{
		int x;
		int  y;
	}point;
	point p[10];
	
int main()
{
	
	int i,n;
	int re;
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		scanf("%d %d",&p[i].x,&p[i].y);
	}
	for(i=0;i<n-1;i++)
	{
		re=sqrt(pow(p[i].x - p[1+i].x,2)+pow(p[i].y - p[i+1].y,2));	
	}
	for(i=0;i<n;i++)
	{
		Quadrant(p[i].x,p[i].y);
	}
	printf("%d\n",re);
	
	return 0;
}

void Quadrant(int x,int y)
{
	if(x>0)
	{
		if(y>0)
		{
			printf("1\n");
		}
		else if (y<0)
		{
			printf("4\n");
		}
	}
	else if(x<0)
	{
		if(y>0)
		{
			printf("2\n");
		}
		else if (y<0)
		{
			printf("3\n");	
		}
	}
}
