#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include<math.h>
int main()
{
	FILE *fp,*fp2;
	char s[50]=" ";
	char *token ,a[2];
	int n;
	int i,j=0,k=0,cnp,quantity;
	int c[15],q[15],cn;
	float price,p[15],t;
	int qpc,qp,qe;
	fp=fopen("input.txt","r");
	fp2=fopen("input.txt","a");
	if(fp==NULL)
	{
		printf("Can't open file");
	}
	printf("Welcome to KMUTNB Shop\n");
	printf("The list of product:\n");
	
	while(fgets(s,sizeof(s),fp)!=NULL)
	{
		token= strtok(s ," ");
		int col=0;
		while(token!=NULL)
		{
			switch(col)
			{
				case 0:cnp=atoi(token);
				break;
				case 1:strcpy(s,token);
				break;
				case 2:price=atof(token);
				break;
				case 3:quantity=atoi(token);
				break;
			}
			col++;
			token=strtok(NULL," ");
		}
		c[j]=cnp;
		q[j]=quantity;
		p[j]=price;
		printf("%d %s %.1f %d\n",c[j],s,p[j],q[j]);
		j++;
	}
	qpc=q[0];
	qp=q[1];
	qe=q[2];
	fprintf(fp2,"\n");
	do
	{
		printf("Please enter the product code:");
		scanf("%d",&cn);
		if(cn==100)
		{
			printf("You have chosen Pencil with Price %.2f\n",p[0]);
			printf("How many:");
			scanf("%d",&n);
			qpc=q[0]-n;
			t=p[0]*n;
			printf("Your total price is %.0f\n",t);
			fprintf(fp2,"100 Pencil 25.0 %d\n",qpc);
			fprintf(fp2,"101 Pen 90.0 %d\n",qp);
			fprintf(fp2,"103 Eraser 12.0 %d\n",qe);
		}
		else if(cn==101)
		{
			printf("You have chosen Pen with Price %.2f\n",p[1]);
			printf("How many:");
			scanf("%d",&n);
			qp=q[1]-n;
			t=p[1]*n;
			printf("Your total price is %.0f\n",t);
			fprintf(fp2,"100 Pencil 25.0 %d\n",qpc);
			fprintf(fp2,"101 Pen 90.0 %d\n",qp);
			fprintf(fp2,"103 Eraser 12.0 %d\n",qe);
		}
		else if(cn==103)
		{
			printf("You have chosen Eraser with Price %.2f\n",p[2]);
			printf("How many:");
			scanf("%d",&n);
			qp=q[2]-n;
			t=p[2]*n;
			printf("Your total price is %.0f\n",t);
			fprintf(fp2,"100 Pencil 25.0 %d\n",qpc);
			fprintf(fp2,"101 Pen 90.0 %d\n",qp);
			fprintf(fp2,"103 Eraser 12.0 %d\n",qe);	
		}
		printf("THANK YOU.\n");
		printf("Do you want to continue(y/n):");
		scanf("%s",a);
	}while(a[0]!='n');
	fclose(fp);
	fclose(fp2);
	printf("The shop is closing\n");
	return 0;
}
