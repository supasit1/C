#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <conio.h>
int main()
{
	FILE *most , *Result1;
	char ch;
	most=fopen("5most.txt","r");
	Result1=fopen("Result1.txt","w");
	if(most==NULL||Result1==NULL)
	{
		printf("Can't open file");
		return(-1);
	}
	else
	{
		ch = fgetc(most);
		while(ch!= EOF)
		{
			printf("%c",toupper(ch));
			fprintf(Result1,"%c",toupper(ch));
			ch = fgetc(most);
		}
	}
	fclose(most);
	fclose(Result1);
	
	getch();
	return 0;
}
