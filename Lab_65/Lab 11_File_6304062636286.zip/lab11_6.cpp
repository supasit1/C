#include<stdio.h>

int main()
{
	FILE *fp,*fp2;
	
	char ch;
	int n,a,A,v,sp,c;
	
	fp=fopen("5ways.txt","r");
	fp2=fopen("results.txt","w");
	if(fp==NULL)
	{
		printf("Can't open file");
	}
	
	ch=fgetc(fp);
	while(ch!=EOF)
	{
		//printf("%c",ch);
		if(ch>='0' && ch<='9')
		{
			n++;
		}
		
		if(ch>='a'&& ch<='z')
		{
			a++;
			if(ch!='a'&&ch!='e'&ch!='i'&&ch!='o'&ch!='u')
			{
				v++;
			}
		}
		if(ch>='A'&& ch<='Z')
		{
			A++;
			if(ch!='A'&&ch!='E'&ch!='I'&&ch!='O'&ch!='U')
			{
				v++;
			}
		}		
		else
		{
			if(ch!=32)
			{
				sp++;
			}
		}
		ch=fgetc(fp);
	}
	c=a+A;
	fprintf(fp2,"number of integer is		     	%d\n",n);
	fprintf(fp2,"number of small letters is		 %d\n",a);
	fprintf(fp2,"number of big letters is		 %d\n",A);
	fprintf(fp2,"number of consonants is		 %d\n",c);
	fprintf(fp2,"number of vowels is 			 %d\n",v);
	fprintf(fp2,"number of special characters is 	%d\n",sp);
	
	printf("number of integer is 		 	%d\n",n);
	printf("number of small letters is	 	%d\n",a);
	printf("number of big letters is  		%d\n",A);
	printf("number of consonants is  		%d\n",c);
	printf("number of vowels is 		 	%d\n",v);
	printf("number of special characters is 	%d\n",sp);
	fclose(fp);
	fclose(fp2);
	return 0;
}
