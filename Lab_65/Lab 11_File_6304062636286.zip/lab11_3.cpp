#include <stdio.h>

typedef struct 
{
	char fname[50],lname[50];
	double id;
	int mid,final,lab;	 
}Student;
int main()
{
	int i,num;
	printf("Enter Number of student:");
	scanf("%d",&num);
	Student stu[100];
	FILE *fp;
	
	for(i=0;i<num;i++)
	{
		printf("Number %d\n",i+1);
		printf("Enter Firstname lastname:");
		scanf("%s %s",stu[i].fname,stu[i].lname);
		printf("Enter ID:");
		scanf("%lf",&stu[i].id);
		printf("Enter Midterm:");
		scanf("%d",&stu[i].mid);
		if(stu[i].mid>30)
		{
			printf("Don't entered more than 30 scores\n");
			printf("Please re-enter scores.:");
			scanf("%d",&stu[i].mid);
		}
		printf("Enter Final:");
		scanf("%d",&stu[i].final);
		if(stu[i].final>50)
		{
			printf("Don't entered more than 50 scores\n");
			printf("Please re-enter scores.:");
			scanf("%d",&stu[i].final);
		}
		printf("Enter Lab:");
		scanf("%d",&stu[i].lab);
		if(stu[i].lab>20)
		{
			printf("Don't entered more than 20 scores\n");
			printf("Please re-enter scores.:");
			scanf("%d",&stu[i].lab);
		}
	}
	fp=fopen("ComPro2_Scores.txt","w");
	if(fp==NULL)
	{
		printf("Can't open file");
		return -1;
	}
	
	for(i=0;i<num;i++)
	{
		fprintf(fp,"%s %s/%.0lf/%d/%d/%d\n",stu[i].fname,stu[i].lname,stu[i].id,stu[i].mid,stu[i].final,stu[i].lab);
	}
	fclose(fp);
	return 0;	
}
