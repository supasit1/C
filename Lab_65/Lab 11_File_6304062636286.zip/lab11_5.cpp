#include<stdio.h>
#include<windows.h>

COORD coord={0,0};

void gotoxy(int x,int y)
{
	coord.X=x; 
	coord.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

int main()
{
	FILE *fp;
	char ch,c;
	int x,y,a;
	char f[1000];
	printf("Enter number of file name:");
	scanf("%d",&a);
	if(a==1)
	{
		char f[1000]="File01.txt";
	}
	else if(a==2)
	{
		char f[1000]="File02.txt";
	}
	else if(a==4)
	{
		char f[1000]="File04.txt";
	}
	else if(a==6)
	{
		char f[1000]="File06.txt";
	}
	fp=fopen(f,"r");
	if(fp==NULL)
	{
		printf("Can't open file");
	}
	while(ch=fscanf(fp,"%d %d %c",&x,&y,&c)!=EOF)
	{
		gotoxy(x,y);
		printf("%c\n",c);
	}
	//system("cls");
	system("COLOR F1");
	fclose(fp);
	return 0;
}
