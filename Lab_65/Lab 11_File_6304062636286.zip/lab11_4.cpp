#include <stdio.h>
#include <string.h>
#include<stdlib.h>
#include<math.h>
typedef struct 
{
	char fname[50],lname[50],id[50];
	int mid,final,lab;	 
}Student;
int main()
{
	float c;
	int i,j,num,t[50],n;
	char ch;
	char s[100]="";
	char *token ;
	int max,min;
	float ave;
	float sd,d;
	//printf("Enter Number of student:");
	//scanf("%d",&num);
	Student stu;
	FILE *fp,*fp2;
	fp=fopen("ComPro2_Scores.txt","r");
	fp2=fopen("Result4.txt","w");
	if(fp==NULL)
	{
		printf("Can't open file");
		return -1;
	}
	fprintf(fp2,"Subject : Computer Programming 2\n");
	fprintf(fp2,"No.	ID		Name-Surname 	Total 	Grade\n");
	fprintf(fp2,"-------------------------------------------------------------------------------\n");
	printf("Subject : Computer Programming 2\n");
	printf("No.	ID		Name-Surname 	Total 	Grade\n");
	printf("-------------------------------------------------------------------------------\n");
	while(fgets(s,sizeof(s),fp)!=NULL)
	{
		//printf("str= %s",s);
		token= strtok(s ,"/");
		int col=0;
		while(token!=NULL)
		{
			switch(col)
			{
				case 0:strcpy(stu.fname,token);
				break;
				case 1:strcpy(stu.id,token);
				break;
				case 2:stu.mid=atoi(token);
				break;
				case 3:stu.final=atoi(token);
				break;
				case 4:stu.lab=atoi(token);
			}
			col++;
			token=strtok(NULL,"/");
		}
		t[n]=stu.mid+stu.final+stu.lab;;
		if(t[n]>80)
		{
			ch='A';
		}
		else if(t[n]>70)
		{
			ch='B';
		}
		else if(t[n]>60)
		{
			ch='C';
		}
		else if(t[n]>50)
		{
			ch='D';
		}
		else if(t[n]<=50)
		{
			ch='F';
		}
		fprintf(fp2,"%d %15s %15s %10d %10c\n",n+1,stu.id,stu.fname,t[n],ch);
		printf("%d %15s %15s %10d %10c\n",n+1,stu.id,stu.fname,t[n],ch);
		j++;
		n++;
	}
	fprintf(fp2,"-------------------------------------------------------------------------------\n");
	printf("-------------------------------------------------------------------------------\n");
	min=t[0];
	for(i=0;i<n;i++)
	{
		if(min>t[i])
		{
			min=t[i];
		}
		else if(max<t[i])
		{
			max=t[i];
		}
	}
	//Average
	for(i=0;i<n;i++)
	{
		ave=ave+t[i];
	}
	ave=ave/n;
	for(i=0;i<n;i++)
	{
		sd+=pow(t[i]-ave,2);
	}
	sd=sd/n;
	fprintf(fp2,"Number of Students : %d\n",n);
	fprintf(fp2,"Max score :%d\n",max);
	fprintf(fp2,"Average scores : %.2f\n",ave);
	fprintf(fp2,"min score :%d\n",min);
	fprintf(fp2,"SD:%.2lf\n",sqrt(sd));
	printf("Max score :%d\n",max);
	printf("Average scores : %.2f\n",ave);
	printf("min score :%d\n",min);
	printf("SD:%.2lf\n",sqrt(sd));
	fclose(fp);
	fclose(fp2);
	return 0;	
}
