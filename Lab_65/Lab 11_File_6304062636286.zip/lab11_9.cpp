#include<stdio.h>
#include <conio.h>
#include<windows.h>

void insertionsort(int list[],int last);
int main()
{
	FILE *fp,*fp2;
	int list[15],i;
	int last=10;
	char nf[100];
	
	printf("Please enter number of digit for sorting: 10\n");
	for(i=0;i<10;i++)
	{
		scanf("%d",&list[i]);
		fprintf(fp,"%d ",list[i]);
	}
	printf("Please enter file name to save:");
	scanf("%s",nf);
	fp=fopen(nf,"w");
	if(fp==NULL)
	{
		printf("Can't open file");
	}
	for(i=0;i<10;i++)
	{
		fprintf(fp,"%d ",list[i]);
	}
	fclose(fp);
	fflush(stdin);
	printf("-------------------------------\n");
	printf("Now, you have the following sorted number:\n");
	insertionsort(list,last);
	for(i=0;i<10;i++)
	{
		printf("%d ",list[i]);
	}
	printf("\n");
	printf("Please enter file name:");
	scanf("%s",nf);
	fp2=fopen(nf,"w");
	if(fp==NULL)
	{
		printf("Can't open file");
	}
	for(i=0;i<10;i++)
	{
		fprintf(fp2,"%d ",list[i]);
	}
	printf("FILE IS ALREADY SAVED.\n");
	fclose(fp2);
	return 0;
}

void insertionsort(int list[],int last)
{
	int walk,temp;
	bool located;
	
	for(int current=1;current<last;current++)
	{
		located = false;
		temp=list[current];
		for(walk=current-1;walk >=0 && !located;)
		{
			if(temp>list[walk])
			{
				list[walk+1]=list[walk];
				walk--;
			}
			else
			{
				located=true;
			}
		}
		list[walk+1]=temp;
	}
	return;
}
