#include<stdio.h>
#define MAXSIZE 100
typedef struct
{
	char id[20];
	char fname[20],sname[20],oc[20],s[2];
	char ad[100];
	int age;
	char h[30];
}person;


int main()
{
	FILE *fp,*fp2;
	person ps[MAXSIZE],ps2;
	int i;
	char c[2];
	char nf[MAXSIZE];
	char h[10];
	printf("Please enter name of file:");
	scanf("%s",nf);
	fflush(stdin);
	fp=fopen(nf,"w");
	if(fp==NULL)
	{
		printf("Can't open file");
	}
	do
	{
		printf("Please enter ID:");
		gets(ps[i].id);
		printf("Please enter name:");
		gets(ps[i].fname);
		printf("Please enter surname:");
		gets(ps[i].sname);
		printf("Please enter occupation:");
		gets(ps[i].oc);
		printf("Please enter age:");
		scanf("%d",&ps[i].age);
		fflush(stdin);
		printf("Please enter sex:");
		gets(ps[i].s);
		printf("Please enter address:");
		gets(ps[i].ad);
		//write
		fprintf(fp,"ID: %s\n",ps[i].id);
		fprintf(fp,"name: %s\n",ps[i].fname);
		fprintf(fp,"surname: %s\n",ps[i].sname);
		fprintf(fp,"occupation: %s\n",ps[i].oc);
		fprintf(fp,"age: %d\n",ps[i].age);
		fprintf(fp,"sex: %s\n",ps[i].s);
		fprintf(fp,"address: %s\n",ps[i].ad);
		
		
		printf("Do you want to continue (�y/n�):");
		scanf("%s",c);
		i++;
		fflush(stdin);
	}while(c[0]!='n');
	fclose(fp);
	fp2=fopen("person.txt","r");
	if(fp2==NULL)
	{
		printf("Can't open file");
	}
	fscanf(fp2,"%s",ps[0].h);
	fscanf(fp2,"%s",ps[0].id);
	fflush(stdin);
	fscanf(fp2,"%s",ps[1].h);
	fscanf(fp2,"%s",ps[0].fname);
	fflush(stdin);
	fscanf(fp2,"%s",ps[2].h);
	fscanf(fp2,"%s",ps[0].sname);
	fflush(stdin);
	fscanf(fp2,"%s",ps[3].h);
	fscanf(fp2,"%s",ps[0].oc);
	fflush(stdin);
	fscanf(fp2,"%s",ps[4].h);
	fscanf(fp2,"%d",&ps[0].age);
	fflush(stdin);
	fscanf(fp2,"%s",ps[5].h);
	fscanf(fp2,"%s",ps[0].s);
	fflush(stdin);
	//
	fscanf(fp2,"%s",ps[6].h);
	fscanf(fp2,"%s",ps[7].h);
	fscanf(fp2,"%s",ps[8].h);
	fscanf(fp2,"%s",ps[9].h);
	fscanf(fp2,"%s",ps[10].h);
	fscanf(fp2,"%s",ps[11].h);
	//fscanf(fp2,"%s",ps[12].h);
	fscanf(fp2,"%s",ps[1].id);
	fflush(stdin);
	fscanf(fp2,"%s",ps[12].h);
	fscanf(fp2,"%s",ps[1].fname);
	fflush(stdin);
	fscanf(fp2,"%s",ps[13].h);
	fscanf(fp2,"%s",ps[1].sname);
	fflush(stdin);
	fscanf(fp2,"%s",ps[14].h);
	fscanf(fp2,"%s",ps[1].oc);
	fflush(stdin);
	fscanf(fp2,"%s",ps[15].h);
	fscanf(fp2,"%d",&ps[1].age);
	fflush(stdin);
	fscanf(fp2,"%s",ps[16].h);
	fscanf(fp2,"%s",ps[1].s);
	fflush(stdin);
	
	printf("-----------------------------------------\n");
	printf ("The list of person whose age over 20 are\n");	
	for(i=0;i<2;i++)
	{
		if(ps[i].age>=20)
		{
		printf("%s %s %s %s %d %s \n",ps[i].id,ps[i].fname,ps[i].sname,ps[i].oc
		,ps[i].age,ps[i].s);
		}
	}
	fclose(fp2);
	return 0;
}
