#include<stdio.h>
#include <conio.h>
#include<windows.h>
int main()
{
	FILE *fp;
	int p,a;
	char c[2];
	char nf[100];
	char pc[100],date[100];
	char pt[100],art[100],comp[100];
	printf("Please enter name of file:");
	gets(nf);
	fp=fopen(nf,"w");
	fprintf(fp,"Please enter name of file:%s\n",nf);
	if(fp==NULL)
	{
		printf("Can't open file");
	}
	do
	{
		a=0;
		printf("Please enter the product code:");
		gets(pc);
		printf("Please enter the product title:");
		gets(pt);
		printf("Please enter the name of artist:");
		gets(art);
		printf("Please enter the issue date:");
		gets(date);
		printf("Please enter the company:");
		gets(comp);
		printf("Please enter price:");
		scanf("%d",&p);
		
		//write
		fprintf(fp,"Please enter the product code: %s\n",pc);
		fprintf(fp,"Please enter the product title: %s\n",pt);
		fprintf(fp,"Please enter the name of artist: %s\n",art);
		fprintf(fp,"Please enter the issue date: %s\n",date);
		fprintf(fp,"Please enter the company: %s\n",comp);
		fprintf(fp,"Please enter price: %d\n",p);
		fprintf(fp,"\n");
		printf("Do you want to continue (y/n):");
		scanf("%s",c);
		if(c[0]=='y')
		{
			a=1;
		}
		fflush(stdin);
	}while(a);
	fprintf(fp,"THANK YOU.THE\n");
	fprintf(fp,"THE CS-KMUTNB MUSIC Shop IS CLOSING.\n");
	fprintf(fp,"NOW, WE ARE WRITING THE REMAINING GOODS FOR TOMORROW!\n");
	printf("THANK YOU.THE\n");
	printf("THE CS-KMUTNB MUSIC Shop IS CLOSING.\n");
	printf("NOW, WE ARE WRITING THE REMAINING GOODS FOR TOMORROW!\n");
	fclose(fp);
	getch();
	return 0;
}
