#include<stdio.h>

int main()
{
	FILE *fpr,*fpw;
	char ch;
	char fnr[100],fnw[100];
	int a=0,e=0,i=0,o=0,u=0;
	printf("Please enter file name to read:");
	scanf("%s",fnr);
	printf("Please enter file name to save:");
	scanf("%s",fnw);
	fpr=fopen(fnr,"r");
	fpw=fopen(fnw,"w");
	if(fpr==NULL)
	{
		printf("Can't open file\n");
	}
	ch=fgetc(fpr);
	while(ch!=EOF)
	{
		printf("%c",ch);
		if(ch=='a')
		{
			a++;
		}
		else if(ch=='e')
		{
			e++;
		}
		else if(ch=='i')
		{
			i++;
		}
		else if(ch=='o')
		{
			o++;
		}
		else if(ch=='u')
		{
			u++;
		}	
		ch=fgetc(fpr);
	}
	fprintf(fpw,"Number of Vowels in %s are\n",fnr);
	fprintf(fpw,"a: %d\ne: %d\ni: %d\no: %d\nu: %d",a,e,i,o,u);
	printf("\n-------------------------------\n");
	printf(" FILE IS ALREADY SAVED.\n");
	printf("-------------------------------\n");
	printf("Number of Vowels in %s are",fnr);
	printf("\na: %d\ne: %d\ni: %d\no: %d\nu: %d",a,e,i,o,u);
	fclose(fpr);
	fclose(fpw);
	return 0;
}
