#include<stdio.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <conio.h>

int main()
{
	FILE *Test2,*Result2;
	char ch;
	char t[1000]="Test2.txt";
	char re[1000]="Result2.txt";
	int i=0,len;
	Test2=fopen(t,"r");
	Result2=fopen(re,"w");
	
	if(Test2==NULL && Result2==NULL)
	{
		printf("Can't open file'");
		return(-1);
	}
	else
	{
		ch=fgetc(Test2);
		fseek(Test2,1,SEEK_END);
		len=ftell(Test2);
		while(i<len)
		{
			i++;
			fseek(Test2,-i,SEEK_END);
			fputc(ch,Result2);
			printf("%c",ch);
			ch=fgetc(Test2);
		}	
	}
	fclose;
	return 0;
}
