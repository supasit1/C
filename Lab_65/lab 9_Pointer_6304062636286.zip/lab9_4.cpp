#include<stdio.h>

void x(int n);
int main()
{
	int i,n;
	scanf("%d",&n);
	char s[n];
	for(i=0;i<n;i++)
	{
		scanf("%s",&s[i]);
	}
	for(i=0;i<n;i++)
	{
		printf("%c",*(s+i));
	}
	for(i=0;i<n;i++)
	{
		printf("%c",*(s+i)+1);
	}
	for(i=0;i<n;i++)
	{
		printf("%c",*(s+i)+2);
	}
	return 0;
}
