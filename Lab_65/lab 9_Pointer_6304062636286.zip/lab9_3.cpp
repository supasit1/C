#include<stdio.h>
#include<string.h>

void rs(char *s);
int main()
{
	int i,count;
	int n,a[100];
	char s[100];
	
	gets(s);
	n =strlen(s);
	rs(s);
	printf("%s\n",s);
	
	for(i=0;i<n;i++)
	{
		if(s[i]>=48&& s[i]<=57)
		{
			count++;
		}
	}
	printf("%d\n",count-1);
	return 0;
}

void rs(char *s)
{
	int i,n,temp;
	n =strlen(s);
	for(i=0;i<n/2;i++)
	{
		temp = s[i];
		s[i] = s[n-i-1];
		s[n-i-1] = temp;
	}
}


