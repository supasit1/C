#include<stdio.h>

int main()
{
	int i = 3, j = 5, *p = &i, *q = &j, *r;
	double x = 2.50;
	
	//printf("1.*p = %d\n",*p);
	//printf("2.*q = %d\n",*q);
	//r=p;
	//printf("3.*r = %d\n",*r);
	//r=&j;
	//printf("4.*r = %d\n",*r);
	//r=&x;
	//printf("5.*r = %d\n",*r);
	printf("6.**&p = %d\n",**&p);
	printf("7.*p-1 = %d\n",*p-1);
	printf("8.*p+*q = %d\n",*p+*q);
	printf("9.++*p = %d\n",++*p);
	printf("10.7**q+7 = %d\n",7**q+7);
	return 0;
}
