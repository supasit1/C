#include<stdio.h>
#include<math.h>
int main()
{
	int i,n,h[n],sum=0;
	float mean=0,sd=0;
	
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		scanf("%d",&h[i]);
		mean = mean + h[i];
	}
	mean= mean/n;
	for(i=0;i<n;i++)
	 {
	  sd+= pow((h[i]-mean),2);
	 }
	printf("%.2f",sqrt(sd/(n-1)));
	return 0;
}
