#include<stdio.h>
#include<math.h>
int main()
{
	int i,j,n,dx,dy;
	scanf("%d",&n);
	float x[n],y[n],check=0,ans=0;
	
	for(i=0;i<n;i++)
	{
		scanf("%f %f",&x[i],&y[i]);
	}
	
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(i==0&&j==1)
			{
				ans=sqrt((pow(x[j]-x[i],2))+(pow(y[j]-y[i],2)));
			}
		else
		{
			check = sqrt((pow(x[j]-x[i],2))+(pow(y[j]-y[i],2)));
			if(check < ans)
			{
				ans=check;
				dx=i+1;
				dy=j+1;
			}
			else
			{
			}
		}
		}
	}
	printf("%d %d %.2f\n",dx,dy,ans);
	
	return 0;
}
