#include<stdio.h>

int main()
{
	int i,j,a,b;
	scanf("%d %d",&a,&b);
	int m[a][b],t[a][b];
	
	for(i=0;i < a;i++)
	{
		for(j=0;j<b;j++)
		{
			scanf("%d",&m[i][j]);
		}
	}
	for(i=0;i<a;i++)
	{
		for(j=0;j<b;j++)
		{
			t[j][i]=m[i][j];
		}
	}
	printf("\n");
	for(i=0;i<b;i++)
	{
		for(j=0;j<a;j++)
		{
			printf("%d ",t[i][j]);
		}
		printf("\n");
	}
	return 0;
}
