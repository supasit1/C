#include<stdio.h>
#include <math.h>
int main()
{
	int i,j,m,n,l,k,c;
	float t;
	scanf("%d %d",&n,&m);
	int f[n][m];
	scanf("%d %d",&l,&k);
	scanf("%d",&c);

	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&f[i][j]);
			t+=f[i][j];
		}
	}
	t=( t/c) + (l*k);
	printf("%.0f",ceil(t));
	return 0;
}
