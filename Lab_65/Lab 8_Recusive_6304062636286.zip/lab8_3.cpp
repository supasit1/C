#include<stdio.h>

int Fibonacci(int x);

int main()
{
	int n;
	
	printf("Enter month:");
	scanf("%d",&n);
	
	int fibo=Fibonacci(n);
	printf("Fibonacci = %d",fibo);
	return 0;
}

int Fibonacci(int x)
{
	if(x==0)
	{
		return 0;
	}
	else if (x==1)
	{
		return 1;
	}
	else if(x>1)
	{
		return Fibonacci(x-1)+Fibonacci(x-2);
	}
}
