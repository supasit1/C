#include<stdio.h>

int recurring(int x);

int main()
{
	int n;
	printf("Enter number:");
	scanf("%d",&n);
	int r=recurring(n);
	printf("recurring = %d",r);
	return 0;
}

int recurring(int x)
{
	if(x==0)
	{
		return 0;
	}
	else if(x==1)
	{
		return 1;
	}
	else if(x>1)
	{
		return x+recurring(x-1);
	}
}

