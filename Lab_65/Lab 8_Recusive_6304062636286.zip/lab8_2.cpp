#include<stdio.h>

double oil(int n);

int main()
{
	double n=oil(2580-2557);
	
	printf("Total oil: %.2lf",n);
	return 0;
}

double oil(int n)
{
	if(n==0)
	{
		return 25000000;
	}
	else
	{
		return 25000000-(25000000*0.1)*(n);
	}
}
