#include<stdio.h>
#include<math.h>

double deposit(double p); 

int main()
{
	int n;
	printf("Enter Days:");
	scanf("%d",&n);
	double p=deposit(n);
	
	printf("Total deposit: %.2lf",p);
	return 0;
}

double deposit(double p)
{
	if(p==0)
	{
		return 10000;
	}
	else
	{
		return  pow(1.05,p)*10000;
	}
}

