#include<stdio.h>
#include<conio.h>
#include<math.h>

double a,b,c,x,x1,x2,y,y2;

void polynomial();
void complex();

int main()
{
	printf("Enter Value of a:");
	scanf("%lf",&a);
	printf("Enter Value of b:");
	scanf("%lf",&b);
	printf("Enter Value of c:");
	scanf("%lf",&c);
	
	if(a==0&&b==0)
	{
		printf("ERROR! This is not a polynomial equation");
	}
	else if(a==0)
	{
		x=-c/b;
		printf("The value of X = %.2lf",x);
	}
	else if((b*b)-4*a*c>=0)
	{
		polynomial();
	}
	else
	{
		complex();
	}
	return 0;
}

void polynomial()
{
	x1=(-b+ sqrt((b*b)-(4*a*c)))/(2*a);
	x2=(-b- sqrt((b*b)-(4*a*c)))/(2*a);
	printf("The Root of Polynomial X1= %.2lf\n",x1);
	printf("The Root of Polynomial X2= %.2lf\n",x2);
}

void complex()
{
	y=-b/(2*a);
	y2=sqrt(fabs((b*b)-4*a*c))/(2*a);
	printf("Complex Solution X1= %.2lf+ %.2lf*i\n",y,y2);
	printf("Complex Solution X2= %.2lf+ %.2lf*i\n",y,y2);
}

