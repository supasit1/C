#include<stdio.h>

int i,j,min=1000,max=0,x;
float sum,mean;

void findmin(int data[]);
void findmax(int data[]);
void sort(int data[]);

int main()
{
	int data[10];
	for(i=0;i < 10;i++)
	{
		scanf("%d",&data[i]);
		sum+=data[i];
	}
	mean=sum/2;
	
	findmin(data);
	findmax(data);
	sort(data);
	
	printf("\nMin= %d ,Max= %d ,Mean = %.2f\n",min,max,mean);
	
	printf("Sorting is ");
	for(i=0;i<10;i++)
	{
		printf("%d ",data[i]);
	}
	return 0;
}

void findmin(int data[])
{
	for(i=0;i<10;i++)
	{
		if(min > data[i])
		{
			min=data[i];
		}
	}
}

void findmax(int data[])
{
	for(i=0;i<10;i++)
	{
		if(max< data[i])
		{
			max=data[i];
		}
	}
}

void sort(int data[])
{
	for(i=0;i<9;i++)
	{
		for(j=i+1;j<10;j++)
		{
			if(data[j] < data[i])
			{
				x=data[j];
				data[j]=data[i];
				data[i]=x;
			}
		}
	}
}


