#include<stdio.h>

int main()
{
	int height;
	
	scanf("%d",&height);
	
	if(height>175)
	{
		printf("you are Tall");
	}
	else if(height>165)
	{
		printf("you are quite tall");
	}
	else if(height>155)
	{
		printf("you are quite short ");
	}
	else
	{
		printf("you are short ");
	}
	return 0;
}
