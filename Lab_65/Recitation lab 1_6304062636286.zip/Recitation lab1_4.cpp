#include<stdio.h>
#include<math.h>

long int FindNFact();

int main()
{
	long int a=FindNFact();
	printf("Value of n! is %ld",a);
	return 0;
}

long int FindNFact()
{
	long int nfact=1,n,i;
	
	printf("Enter Value of n: ");
	scanf("%ld",&n);
	
	for(i=1;i<=n;i++)
	{
		nfact *= i;
	}
	
	return nfact;
}
