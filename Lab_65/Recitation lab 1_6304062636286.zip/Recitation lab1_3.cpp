#include<stdio.h>
#include<math.h>

double FindSeries();

int main()
{
	double sum=FindSeries() ;
	
	printf("Value of sum is %.3lf",sum);
	
	return 0;
}

double FindSeries()
{
	int i;
	int n;
	double sum;
	printf("Enter Value of n:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		sum+=pow(-1,i+1)/(2*i-1);
	}
	return sum;
}
